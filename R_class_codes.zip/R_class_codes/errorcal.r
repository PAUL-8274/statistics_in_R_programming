#how to calculate errors in R:

x=c(2,15,4,9,100)
y=c(4,225,16,81,91)
errors=c(1,2,3,4,5)
plot(x,y,type='o',xlab='value of x',ylab='value of y')
arrows(x,y+errors,x,y-errors,col='blue',angle=90,code=3,length=0.06)
x11()




