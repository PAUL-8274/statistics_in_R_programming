
#define_a_function

3d_values<-function(length,width,height) {
volume=(length*width*height)
surface_area=(2*(length*width+width*height+length*height))
ratio=(volume/surface_area)
return ratio
}

#using_the_function
l=21.5
w=32.5
h=12.2
answer<-3d_values(l,w,h)
print(answer)

#define_a_function
add_vec=function(vec1,vec2) {
    addition=(vec1+vec2)
    return(addition)
    
}

#using_the_function

a=c(1,2,4,6,78,5)
b=c(6,7,8,9,3,8)
final=add_vec(a,b)
print(final)
