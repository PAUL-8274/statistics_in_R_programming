#how to run for loop

for(i in 1:10)
{
print(i)
}


#
x=c(20,30,40,50,60,70,80)
for(a in x)
{
print(a)
}

#
for(i in 1:length(x))
{
print(x[i])
}

#how to find the sum of elements:
x=c(20,30,40,50,60,70,80)
sum=0
for(a in x)
{
sum=sum+a
}
print(sum)


