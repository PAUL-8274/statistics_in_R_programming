dat=read.csv("SOCR_height_weight_data.csv",header=T)
print(colnames(dat))
height=dat$Height.Inches*2.3
weight=dat$Weight.Pounds*0.45
#split canvas into 2*2
par(mfrow=c(2,2))
#par(mfrcol=c(2,2))
#histogram_of_height
hist(height,breaks=40,col="red")
hist(weight,breaks=40,col="red")
hist(weight,breaks=30,col="blue")
hist(height,breaks=40,col="blue")
#histogram_of_unit_gaussian_of _height
z_height=(height-mean(height))/sd(height)
hist(z_height,breaks=40,col="blue")
#histogram_of_unit_gaussian_of _weight
z_weight=(weight-mean(weight))/sd(weight)
hist(z_weight,breaks=40,col="magenta")
#split canvas into 2*2
par(mfrow=c(2,2))
par(mfcol=c(2,3))
z_weight=height-mean(weight)/sd(weight)
hist(z_weight,breaks=40,col="magenta")
#find_the_unit_gaussian
#prob=0.68
a=subset(z_height,(z_height>-1)&(z_height<1))
print(length(a)/length(z_height))
#prob=0.954
b=subset(z_height,(z_height>-2)&(z_height<2))
print(length(b)/length(z_height))
#prob=0.99
c=subset(z_height,(z_height>-3)&(z_height<3))
print(length(c)/length(z_height))

