alpha=0.05
dat=read.csv("2_way_anova.csv",header=TRUE)
g=c(mean(dat$G1),mean(dat$G2),mean(dat$G3),mean(dat$G4))
c=c(mean(c(dat$G1[1],dat$G2[1],dat$G3[1],dat$G4[1])),mean(c(dat$G1[2],dat$G2[2],dat$G3[2],dat$G4[2])),mean(c(dat$G1[3],dat$G2[3],dat$G3[3],dat$G4[3])))
em=mean(c(dat$G1,dat$G2,dat$G3,dat$G4))
a=nrow(dat)
b=(ncol(dat)-2)
ssb=a*(sum(c((g[1]-em)^2,(g[2]-em)^2,(g[3]-em)^2,(g[4]-em)^2)))
ssa=b*(sum(c((c[1]-em)^2,(c[2]-em)^2,(c[3]-em)^2)))
x1=c(dat$G1[1],dat$G1[2],dat$G1[3])
x2=c(dat$G2[1],dat$G2[2],dat$G2[3])
x3=c(dat$G3[1],dat$G3[2],dat$G3[3])
x4=c(dat$G4[1],dat$G4[2],dat$G4[3])
x=list(x1,x2,x3,x4)
sse=c()
for(i in 1:b)
{
	for(j in 1:a)
	{
		sse=sum(c(sse,(x[[i]][j]-c[j]-g[i]+em)^2))
	}
}

fa=(ssa/(a-1))/(sse/((a-1)*(b-1)))
fb=(ssb/(b-1))/(sse/((a-1)*(b-1)))

fcra=qf(1-alpha,a-1,(a-1)*(b-1))
fcrb=qf(1-alpha,b-1,(a-1)*(b-1))
print(paste("Fa=",fa,"Fb=",fb,"Fa critical=",fcra,"Fb critical=",fcrb,sep=" "))
if(fa<fcra)
{
	print("Null Hypothesis is accepted")
}else
{
	print("Null Hypothesis is rejected")
}
if(fb<fcrb)
{
	print("Null Hypothesis is accepted")
}else
{
	print("Null Hypothesis is rejected")
}

