#Test script to read and analyse table data
#read a csv data file
1.dat= read.csv('all_data.csv',header=TRUE)
****
#Read text file

2.dat1=read.table('all_data.txt' ,header=TRUE)
********

#Get the data dimension
3.print(dim(dat))

#R-programming
********
4.print(colnames(dat))

******
5.print(dat$ PROBE_NAME[1:30])
*****************
6.print(length(dat$normal1))

*******

7.print(mean(dat$normal1,na.rm=TRUE))

************
8.print(dat[3,])
***********
9.print(dat[,6])
**********

10.fr=dat[1:20,]
print(fr)
************

11.fr=dat[1:30,8:12]
print(fr)
***************
12.fr=subset(dat,dat$normal1<800)
print(fr)
***************

13.fr=subset(dat,(dat$normal1<800)&(dat$cancer1<300))
print(fr)
****************

14.print(dim(fr))
***********

15.plot(fr$normal1,fr$cancer1,col="blue",type="o")
************

16.hist(fr$normal1,breaks=30)
**************
17.x11()#open another window







