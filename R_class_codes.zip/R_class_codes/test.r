a=10
b=12
c=40
d=a*b*c
print(d)
print("Hi")

