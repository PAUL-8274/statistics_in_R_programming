#define u,sigma
#define empty vector v()
#for loop i-1,m
#generate x values from a distribution (u,sigma)
#generate n values from a distribution(u,sigma)
#find mean of x=x_mean
#compute,z=(x_mean - u)/(sigma/root n)
#push it into the vector v
#loop end
#plot histogram of m

u=12.0
sigma=2.5
v=c()

nevent=10000
sample_size=20
for(i in 1:10000)
{ #generate from gausian
#x=rnorm(sample_size,mean=u,sd=sigma)
#u=3
#sigma=sqrt(u)
a=5
b=10
u=(b+a)/2
sigma=sqrt((b-a)^2/12)
#x=rpois(sample_size,lambda=u)
x=runif(sample_size,a,b)
xbar=mean(x)
z=(xbar-u)/(sigma/sqrt(sample_size))
v=c(v,z)
}
hist(v)
#generate from poison
u=3
sigma=sqrt(u)
x=rpois(sample_size,lambda=u)
hist(x)
#generate from unif distribution:
x=runif(sample_size,5,10)
