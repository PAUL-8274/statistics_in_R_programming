#read the file by read commands
data=read.csv("SOCR_height_weight_data.csv",header=T)
print(colnames(data))
#transfer inches to cm and pounds to kg:
h=data$Height.Inches*2.3
w=data$Weight.Pounds*2.4
print(h)
print(w)

z1=(h-mean(h))/sd(h)
print(z1)
z2=(w-mean(w))/sd(w)
print(z2)
par(mfrow=c(2,2))
hist(h,col="blue",breaks=40)
hist(w,col="red",breaks=40)
hist(z1,col="yellow",breaks=40)
hist(z2,col="green",breaks=40)
a=subset(z1,(z1>-1)&(z1<1))
print(length(a))
print(length(a)/length(z1))
b=subset(z2,(z2>-1)&(z2<1))
print(length(b))
print(length(b)/length(z2))





