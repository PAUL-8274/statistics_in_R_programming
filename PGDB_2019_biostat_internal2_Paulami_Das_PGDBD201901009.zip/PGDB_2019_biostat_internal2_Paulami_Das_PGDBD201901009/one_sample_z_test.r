one_sample_z_test <- function(vec,mu,sigma,alpha,alternate) {
    n=length(vec)
    x_bar=mean(vec)
    z=(x_bar-mu)/(sigma/sqrt(n))
    p_val=0
    if(z>0) {
        p_val=1-pnorm(z)
        print("p-value is",p_val)
    } else (z<=0) 
    {
        p_val=pnorm(z)
        print("p-value is",p_val)
    }
    if(alternate=="two_sided") {
        z_critical=qnorm(1-(alpha/2))
        if(z > z_critical) {
            print("null_rejected")
        } else{
            print("null_accepted")
        }
    
    } else if (alternate=="greater") {
        z_critical=qnorm(1-(alpha))
        if(z > z_critical) {
            print("null_rejected")
        } else{
            print("null_accepted")
        }
        
        
     } else if (alternate=="lesser") {
        z_critical=(-(qnorm(1-alpha)))
        if(z > z_critical) {
            print("null_rejected")
        } else{
            print("null_accepted")
        }
    }
    
    return(p_val)
}

a=20
b=c(19.5,14.6,22.5,23.9,17.5,18.6)
c=2
al=0.05
alternate="two_sided"
print(one_sample_z_test(b,a,c,al,alternate))
