two_samp_t_test = function(x,y,alpha,alternative="two-sided"){
    n = length(x)
    m = length(y)
    df= n+m-2
    xbr=mean(x)
    ybr=mean(y)
    sx=sd(x)
    sy=sd(y)
    sp=sqrt((((n-1)*(sx*sx))+((m-1)*(sy*sy)))/(m+n-2))
    t=(xbr-ybr)/(sp*sqrt((1/m)+(1/n)))
    t_critical=0
    null_status=""
    pval=0
    if(alternative =="two-sided"){
        t_critical=qt(1-(alpha/2),df)
        if ((t_critical > t) | (t < -t_critical)){
            null_status="Rejected"
        } 
        else{null_status="Accepted"}
    }
    if(alternative == "greater"){
        t_critical= qt(1-alpha,df)
        if (t > t_critical){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(alternative == "lesser"){
        t_critical = qt(1-alpha,df)
        if(t < -t_critical){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(t >0){
        pval = 1-pt(t,df)
    }else if (t < 0){
        pval = pt(t,df)
    }else{pval=0}
print("two sample t test")
print(paste("n=",n))
print(paste("m=",m))
print(paste("mean x =",xbr))
print(paste("mean y =",ybr)) 
print(paste("t=",t))    
print(paste("df=",df))
print(paste("alpha=", alpha))
print(paste("t_critical=", t_critical))
print(paste("pval=",pval))
print(paste(alternative , "hypothesis"))
print(paste("null hypothesis", null_status ))
}    

x =c(33.38,32.15,33.99,34.1,33.97,34.34,33.95,33.85,34.23,32.73,33.46,34.13,34.45,34.19,34.05)
y=c(34.33,42,25,56,45,34,32,43,67)
alpha=0.05
two_samp_t_test(x,y,alpha,alternative="two-sided")
