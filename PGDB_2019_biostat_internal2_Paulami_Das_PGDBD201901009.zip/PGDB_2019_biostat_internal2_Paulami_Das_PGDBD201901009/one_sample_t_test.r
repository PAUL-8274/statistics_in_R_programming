one_samp_t_test = function(x,mu,alpha,alternative="two-sided"){
    n = length(x)
    df=n-1
    xbr=mean(x)
    s=sd(x)
    t=(xbr-mu)/(s/sqrt(n))
    t_critical=0
    null_status=0
    pval=0
    if(alternative =="two-sided"){
        t_critical=qt(1-(alpha/2),df)
        if ((t_critical > t) | (t < -t_critical)){
            null_status="Rejected"
        } 
        else{null_status="Accepted"}
    }
    if(alternative == "greater"){
        t_critical= qt(1-alpha,df)
        if (t > t_critical){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(alternative == "lesser"){
        t_critical = qt(1-alpha,df)
        if(t < -t_critical){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(t >0){
        pval = 1-pt(t,df)
    }else if (t < 0){
        pval = pt(t,df)
    }else{pval=0}
print("one sample t test")
print(paste("n=",n))
print(paste("mean x =",xbr))
print(paste("t=",t))    
print(paste("df=",df))
print(paste("alpha=", alpha))
print(paste("t_critical=", t_critical))
print(paste("pval=",pval))
print(paste(alternative , "hypothesis"))
print(paste("null hypothesis", null_status ))
}    
x =c(33.38,32.15,33.99,34.1,33.97,34.34,33.95,33.85,34.23,32.73,33.46,34.13,34.45,34.19,34.05)
mu=34.5
alpha=0.05
one_samp_t_test(x,mu,alpha,alternative="two-sided")
