#one way anova


x1=c(92,90,87,105,86,83,102)

x2=c(100,108,98,110,114,97,94)

x3=c(143,149,138,136,139,120,145)

x4=c(147,144,160,149,152,131,134)

x5=c(142,155,119,134,133,146,152)
alpha=0.01
xlis=list(x1,x2,x3,x4,x5)
n=0
m=length(xlis)
sq_sum=0.0
sum=0.0
add_rowsum_sq=0.0
sum_sq=0.0
#n=n+length(xlis[[i]])
for(i in 1:length(xlis)) {
    
    n=n+length(xlis[[i]])
    
    add_rowsum_sq= add_rowsum_sq + (sum(xlis[[i]])^2)/length(xlis[[i]])
    for(j in 1:length(xlis[[i]])) {
        
        sq_sum = sq_sum + (xlis[[i]][j])^2
        
        sum = sum + xlis[[i]][j]
        
        }
}


sum_sq=(sum^2)/n
SSTO=   sq_sum -  sum_sq
SST=  add_rowsum_sq -  sum_sq 
SSE=SSTO-SST
f_critical=qf((1-alpha),m-1,n-m) 
f=(SST/m-1)/(SSE/n-m)
print(paste("SSTO = ",SSTO))

print(paste("SST = ",SST))
print(paste("SSE = ",SSE))

print(paste("F=",f))


print(paste("F_critical=",f_critical))

if (f>f_critical) {
    print(paste("null rejected at a significance level of ",alpha))
} else {
    print(paste("null accepted at a significance level of" ,alpha))
}

print(paste("degrees of freedom",(m-1),",",(n-m)))
