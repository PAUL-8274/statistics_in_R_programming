#(a) Plot a Poisson distribution with a mean 5 in the range 0 to 12. The title of the plot should be ”Poisson distribution : mean = 5”.
x=seq(0,12)
gy=dpois(x,5)
dev.off()
plot(x,gy,type ="o",asp=50,main = "Poisson with mean 5")

#(b) Generate 10000 points randomly drawn from a Gaussian distribution whose mean is 6.0 and standard deviation is 1.6. Plot the histogram of these data points


mu=6
S=1.6
rand = rnorm(10000,mu,S)
hist(rand,breaks = 80,col=rainbow(10),main="histogram of 10000 datapoints")

#(c) For this data, find the number of data points more than 2 standard deviations above the mean value and print this number.

s=subset(rand,(rand>mu+2*S) | (rand<mu-2*S))
n=length(s)

print("the number of data points more than 2 standard deviations above the mean value is = ")

print(n)
