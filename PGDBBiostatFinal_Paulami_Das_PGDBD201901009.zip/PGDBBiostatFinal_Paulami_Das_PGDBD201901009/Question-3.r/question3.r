#Read the given data file ”crop table.txt” into a data frame called ”mydata”.

mydata=read.table("crop_table.txt",header=TRUE)

#(a) Create a bar plot comparing the cultivation area of rice and wheat during 1980-81 and 2012-13. Label the entities properly.

Year1980_81=c(mydata$Rice[4],mydata$Wheat[4])

Year2012_13= c(mydata$Rice[12],mydata$Wheat[12])

dat=data.frame(Year1980_81,Year2012_13)


barplot(height=as.matrix(dat),main="Comparison of Rice VS Wheat Production during 1980-81 and 2012-13",ylab="Percentage Land",xlab="Year",beside=TRUE, col= c("red","green"))
legend("topright",
       c("Rice","Wheat"), cex=1.0,
       bty="n",
       fill=c("red","green"))

#(b) Create a Pie-chart depicting the percentage of cultivation areas of all the crops. Write the legends properly.

Year1990_91=as.numeric(mydata[5,2:10])
lab=colnames(mydata)[2:10]

#print("the percentage of cultivation areas of all the crops 1900-91",Year1990_91)
#Year1990_91
pie(Year1990_91,main="the percentage of cultivation areas of all the crops 1900-91",col=rainbow(10),labels=paste(Year1990_91,"%"),cex=0.8)
legend("topright",lab, fill=rainbow(10))

