print("Null hypotheis H0: μ1=μ2 i.e two groups of placebo and Treatment doesn't differ with respect to mean ")
print("Alternate hypotheis H0: μ1!=μ2 i.e two groups of placebo and Treatment differ with respect to mean")

two_samp_t_test = function(x,y,alpha,alternative="two-sided"){
    n = length(x)
    m = length(y)
    df= n+m-2
    xbr=mean(x)
    ybr=mean(y)
    sx=sd(x)
    sy=sd(y)
    sp=sqrt((((n-1)*(sx*sx))+((m-1)*(sy*sy)))/(m+n-2))
    t=(xbr-ybr)/(sp*sqrt((1/m)+(1/n)))
    t_critical=0
    null_status=""
    pval=0
    if(alternative =="two-sided"){
        t_critical=qt(1-(alpha/2),df)
        #if((w>w_alpha)|(w<(-w_alpha)))
        #) | ( ))
        if( (t> t_critical)|(t < (-t_critical))  ){
            null_status="Rejected"
        } 
        else{null_status="Accepted"}
    }
    if(alternative == "greater"){
        t_critical= qt(1-alpha,df)
        if (t > t_critical){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(alternative == "lesser"){
        t_critical = qt(1-alpha,df)
        if(t < (-t_critical)){
            null_status="Rejected"
        }else{null_status="Accepted"}
    }
    if(t >0){
        pval = 1-pt(t,df)
    }else if (t < 0){
        pval = pt(t,df)
    }else{pval=0}
print("two sample t test")
print(paste("n=",n))
print(paste("m=",m))
print(paste("mean x =",xbr))
print(paste("mean y =",ybr)) 
print(paste("t=",t))    
print(paste("df=",df))
print(paste("alpha=", alpha))
print(paste("t_critical=", t_critical))
print(paste("pval=",pval))
print(paste(alternative , "hypothesis"))
print(paste("null hypothesis", null_status ))
}    

x=c(3.1,5.2,5.3,4.7,5.4,5.7,3.8,6.2,6.9,5.5,4.1,7.8)


y=c(4.9,6.9,7.1,4.9,4.5,6.1,6.4,6.2,6.3,7.4,5.4,4.4)
alpha=0.05

#call_the_function

two_samp_t_test(x,y,alpha,alternative="two-sided")
