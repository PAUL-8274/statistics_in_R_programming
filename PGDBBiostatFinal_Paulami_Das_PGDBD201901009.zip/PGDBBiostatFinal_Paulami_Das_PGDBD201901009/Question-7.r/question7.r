#one way anova
data=read.table("group_data.txt",header=T)

x1=data$Group.1
x2=data$Group.2
x3=data$Group.3
x4=data$Group.4

alpha=0.05

xlis=list(x1,x2,x3,x4)

n=0

m=length(xlis)

sq_sum=0.0

sum=0.0

add_rowsum_sq=0.0

sum_sq=0.0


for(i in 1:length(xlis)) {
    
    n=n+length(xlis[[i]])
    
    add_rowsum_sq= add_rowsum_sq + (sum(xlis[[i]])^2)/length(xlis[[i]])
    
    for(j in 1:length(xlis[[i]])) {
        
        sq_sum = sq_sum + (xlis[[i]][j])^2
        
        sum = sum + xlis[[i]][j]
        
        }
}

f_critical=qf((1-alpha),m-1,n-m) 


sum_sq=(sum^2)/n

SSTO =   sq_sum -  sum_sq

SST =  add_rowsum_sq -  sum_sq 

SSE=SSTO-SST

f=(SST/m-1)/(SSE/n-m)
pval=pf(f,m-1,n-m)

print(paste("SSTO = ",SSTO))

#printing p value
print(paste("pvalue=",pval))

 

print(paste("SST = ",SST))

print(paste("SSE = ",SSE))

print(paste("F=",f))



print(paste("F_critical=",f_critical))

if (f>f_critical) {
    print(paste("null rejected at a significance level of ",alpha))
} else {
    print(paste("null accepted at a significance level of" ,alpha))
}

print(paste("degrees of freedom",(m-1),",",(n-m)))


