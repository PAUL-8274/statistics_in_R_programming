#(a) Read the given data into a data frame called ”indat”.
indat=read.table("crop_table.txt",header=TRUE)
#(b) Create a column consisting of the sum of cultivation areas of Rice, wheat and Cereals over the years.
indat$sum_of_cultivation_areas_of_Rice_wheat_and_Cereals_over_the_years=indat$Rice + indat$Wheat + indat$Cereals
#(c) Create a subset of data in which cereals were cultivated in more than 10 percent of total area and print this sunset.
subdata <- subset(indat, indat$Cereals > 10.0) 
print(subdata)
