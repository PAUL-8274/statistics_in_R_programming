#(a) For each of the five data sets, create a vector whose name is the same as that of the data set.
V1 = c("S1","S2","S3","S4","S5","S6","S7")
V2 = c(233, 255, 199, 265, 200, 215, 207)
V3 = c(10, 20, 30, 40, 50, 60, 70)
V4 = c(12.22, 17.55 )
V5 = c("experiment−1","Method−standard")
#(b) Create a data frame called ”table-1” from the vectors V 1, V 2 and V 3. Print the columns of this data frame separately.
table_1=data.frame(V1,V2,V3)
print("the V1 columns of DataFrames are : ")
print(paste(table_1$V1))
print(paste("the V2 columns of DataFrames are : "))

print(paste(table_1$V2))

print(paste("the V3 columns of DataFrames are : "))

print(paste(table_1$V3))

#(c) Multiply the columns V 2 and V 4 and print the resulting column vector.
print(paste("Multiplication of the columns V 2 and V 4"))

print(paste(V2*V4))

#(d) Create a list called ”alldata” that contains the data frame ”table-1” and the vectors V 4 and V 5
alldata=list(table_1=table_1,V4=V4,V5=V5)


#Access the vector V5 from the list and print its elements.

print(paste("elements of V5 are "))

elem=alldata$V5   #Access the vector V 5 from the list and print its elements.

print(elem)
