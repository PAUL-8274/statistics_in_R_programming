x=c(2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5)

#x is our independent variable

y=c(23.7,25.6,34.0,35.8,44.0,46.0,54.2,55.9,62.5)

# y is our dependent variable

n=length(x)

sum_x=sum(x)

sum_y=sum(y)

sum_x_sq=sum(x^2)

sum_y_sq=sum(y^2)

sum_xy=sum(x*y)

delta=(n*sum_x_sq)-(sum_x**2)

b0=(1/delta)*((sum_y*sum_x_sq)-(sum_x*sum_xy))

b1=(1/delta)*((n*sum_xy)-(sum_x*sum_y))

y_fitted=b0+(b1*x)
#value of SSR

SSR=sum((y_fitted-mean(y))^2)
print(paste("SSR= ", SSR))
#value of SST

SST=sum((y-mean(y))^2)
print(paste("SST= ", SST))
rsquare=SSR/SST
#printing rsquare

print(paste("rsquare= ", rsquare))
#print the intercept

print(paste("values of intercept = ",b0))

#print the slope

print(paste("values of slope = ",b1))

#Plot the data points along with the fitted line

plot(x,y,type="p",col=rainbow(length(x)))

lines(x,y_fitted,type="l",col="blue")

text(4,55,"slope= 4.945 \n intercept= 10.268")#slope intercept changes with every graph.
