##cumulative p-value for a given x value:04/02/19
##dpois(x, lambda, log = FALSE)
    # ppois(q, lambda, lower.tail = TRUE, log.p = FALSE)
     # qpois(p, lambda, lower.tail = TRUE, log.p = FALSE)
    # rpois(n, lambda)


##cumulative p-value for a given x value:
x=9
lambda=0.8
y=ppois(x,lambda)
print(y)
hist(y)


#get x value for a given cumulative prob(p-value)):
pvalue=0.036
lambda=5
x=qpois(pvalue,lambda)
print(x)


#probability for a given x value:
x=9
lambda=5
p=dpois(x,lambda)
print(p)

#generate random deviate:
n=100
lambda=8
r=rpois(n,lambda)
print(r)



