#cumulative p-value for a given x value:04/02/19
z=5
pvalue=pnorm(z)
print(pvalue)

#get x value for a given cumulative prob(p-value)):
pvalue=7
zvalue=qnorm(pvalue)
print(zvalue)

#get x value for a given cumulative prob(p-value)):
z=4
prob_density=dnorm(z)
print(prob_density)
hist(prob_density,breaks=30)

#generate random deviate:

x=rnorm(10000)
print(x[1;30])
hist(x,breaks=40)

#plot
z=seq(-4,4,0.1)
pd=dnorm(z)
print(pd)
plot(z,pd,type="hist",col="blue")


