#cumulative p-value for a given x value:04/02/19
x=5
n=12
p=0.5
cum_prob=pbinom(x,n,p)
print(paste("bi prob density =",cum_prob))

#get x value for a given cumulative prob(p-value)):
pvalue=0.6
n=12
P=0.5
x=qbinom(pvalue,n,P)
print(paste("x=",x))

#probability for a given x value:
n=12
x=3
p=0.5
print(dbinom(x,n,p))

#frequency plot
xx=seq(0,12,1)
yy=dbinom(xx,n,p)
plot(xx,yy,type="h",col="blue")

#generate random deviate:
n=12
p=0.5
x=rbinom(10,n,p)
print(x)

#histogram for random deviate:
n=12
p=0.5
x=rbinom(10000,n,p)
print(x)
hist(x,breaks=15)

