#integration using R programming
a=0
b=pi
n=10000
delta_x=(b-a)/n
area=0.0
for (i in 1:n)
{
x=a+(i-1)*delta_x
fofx=sin(x)
area=area+fofx*delta_x
}

print(area)
